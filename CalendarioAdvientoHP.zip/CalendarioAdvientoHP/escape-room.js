!function () {
  'use strict';

  const dias = Array.from({ length: 24 }, (_, i) => i + 1);
  const tipos = {
    escrita: 'Respuesta escrita',
    opciones: 'Elección entre opciones',
    ordenar: 'Ordenar elementos',
    combinacion: 'Combinación final',
    anagrama: 'Anagrama con fichas',
    recorrido: 'Recorrido en cuadrícula',
    ahorcado: 'Ahorcado',
    ascensor: 'Ascensor con libreta',
    registro: 'Registro lunar',
    nonograma: 'Nonograma',
    maquina: 'Máquina lunar',
    perforado: 'Papel perforado',
    fragmentos: 'Visor de fragmentos',
    electrico: 'Cuadro eléctrico',
    tuberias: 'Tuberías giratorias',
    mantenimiento: 'Ascensor de mantenimiento',
    diagnostico: 'Visores averiados',
    anillos: 'Laberinto de anillos',
    engranajes: 'Mecanismo de engranajes',
    vitral: 'Vitral lunar',
    cerradura: 'Cerradura mecánica'
  };
  const texto = valor => typeof valor === 'string' ? valor : '';
  const lista = valor => Array.isArray(valor) ? valor.filter(item => typeof item === 'string') : [];
  const fechaPuerta = dia => `2026-12-${String(dia).padStart(2, '0')}`;
  const relojMadrid = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Europe/Madrid', year: 'numeric', month: '2-digit', day: '2-digit'
  });

  function capitulo(entrada = {}) {
    const campos = ['titulo', 'instrucciones', 'pregunta', 'apoyo', 'imagen', 'alt', 'audio',
      'acierto', 'premio', 'evidenciaTitulo', 'evidenciaTexto', 'combinacion',
      'recursoTipo', 'recursoDatos', 'transcripcion', 'evidenciaDibujo', 'evidenciaDatos',
      'configuracion', 'normalizacion', 'contexto', 'transicion', 'descubrimientoTitulo', 'descubrimientoTexto'];
    return {
      ...Object.fromEntries(campos.map(campo => [campo, texto(entrada[campo])])),
      tipo: Object.hasOwn(tipos, entrada.tipo) ? entrada.tipo : 'escrita',
      listo: entrada.listo === true,
      respuestas: lista(entrada.respuestas),
      opciones: lista(entrada.opciones),
      correcta: Number.isInteger(entrada.correcta) ? entrada.correcta : -1,
      orden: lista(entrada.orden),
      pistas: lista(entrada.pistas),
      dependencias: [...new Set(lista(entrada.dependencias))]
    };
  }

  function calendario(datos) {
    if (datos?.esquema !== 1 || !Array.isArray(datos.capitulos) || datos.capitulos.length !== 24
        || datos.capitulos.some(item => !item || typeof item !== 'object' || Array.isArray(item))) {
      throw new Error('El archivo debe contener 24 capítulos y usar el formato de respaldo del editor.');
    }
    return {
      esquema: 1,
      partida: typeof datos.partida === 'string' && /^[a-zA-Z0-9-]{1,80}$/.test(datos.partida)
        ? datos.partida : 'demo-2026',
      capitulos: datos.capitulos.map(capitulo),
      experiencia: {
        cartaRotulo: texto(datos.experiencia?.cartaRotulo) || 'CORREO ESPECIAL · COLEGIO HOGWARTS',
        cartaCabecera: texto(datos.experiencia?.cartaCabecera) || 'HOGWARTS · ESCUELA DE MAGIA Y HECHICERÍA',
        cartaFecha: texto(datos.experiencia?.cartaFecha) || 'HOGWARTS, 1 DE DICIEMBRE DE 2026',
        cartaDestinatario: texto(datos.experiencia?.cartaDestinatario) || 'PARA: ANDREA',
        cartaTitulo: texto(datos.experiencia?.cartaTitulo) || 'Una invitación especial',
        cartaTexto: texto(datos.experiencia?.cartaTexto) || 'Querida Andrea:\n\nTenemos el placer de comunicarte que has sido convocada a Hogwarts para vivir un diciembre extraordinario.\n\nEste año, el Cáliz de Fuego ha señalado a una cuarta campeona. Tu nombre ha aparecido donde nadie esperaba encontrarlo y, desde este momento, formas parte de una historia llena de pruebas, secretos y decisiones.\n\nA lo largo de los próximos días descubrirás pistas, superarás desafíos y conocerás qué misterio se esconde tras esta inesperada elección.\n\nPrepara tu varita. El castillo te espera.',
        cartaFirma: texto(datos.experiencia?.cartaFirma) || 'Atentamente,\nEl equipo de selección de Hogwarts',
        cartaSello: texto(datos.experiencia?.cartaSello) || 'H',
        cartaBoton: texto(datos.experiencia?.cartaBoton) || 'Aceptar la invitación',
        cartaSaltar: texto(datos.experiencia?.cartaSaltar) || 'Entrar directamente al castillo',
        historiaActiva: datos.experiencia?.historiaActiva === true,
        historiaTitulo: texto(datos.experiencia?.historiaTitulo),
        historiaTexto: texto(datos.experiencia?.historiaTexto),
        historiaBoton: texto(datos.experiencia?.historiaBoton) || 'Comenzar la investigación',
        revelacion: texto(datos.experiencia?.revelacion),
        introduccion: datos.experiencia?.introduccion !== false,
        final: datos.experiencia?.final === true,
        nota: texto(datos.experiencia?.nota),
        pista: texto(datos.experiencia?.pista),
        codigo: texto(datos.experiencia?.codigo) || 'HOGWARTS',
        mensaje: texto(datos.experiencia?.mensaje),
        permitirNombre: datos.experiencia?.permitirNombre === true
      }
    };
  }

  // Una tarjeta por día. Su ID depende del día que la otorga y conserva el vínculo al editarla.
  const idEvidencia = dia => `evidencia-${dia}`;

  function evidencias(datos) {
    return dias.flatMap(dia => {
      const reto = datos.capitulos[dia - 1];
      if (!reto.evidenciaTitulo.trim() || !reto.evidenciaTexto.trim()) return [];
      return [{ id: idEvidencia(dia), dia, titulo: reto.evidenciaTitulo, texto: reto.evidenciaTexto,
        dibujo: reto.evidenciaDibujo, datos: reto.evidenciaDatos }];
    });
  }

  function rutaMultimedia(valor) {
    const ruta = valor.trim();
    if (!ruta || ruta.startsWith('//') || ruta.startsWith('\\')) return '';
    try {
      const url = new URL(ruta, 'https://calendario.example/');
      return ['https:', 'http:'].includes(url.protocol) ? ruta : '';
    } catch {
      return '';
    }
  }

  function normalizar(valor) {
    return valor.normalize('NFD').replace(/\p{M}/gu, '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('es');
  }

  function errores(datos, dia) {
    const reto = datos.capitulos[dia - 1];
    const avisos = [];
    if (window.EscapeRoom.especiales?.esEspecial(reto.tipo)) {
      avisos.push(...window.EscapeRoom.especiales.errores(reto));
    }
    if (!reto.titulo.trim()) avisos.push('escribe un título');
    if (!reto.instrucciones.trim()) avisos.push('escribe las instrucciones');
    if (reto.tipo === 'escrita' && !reto.respuestas.some(normalizar)) avisos.push('añade una respuesta válida');
    if (reto.tipo === 'opciones' && (reto.opciones.filter(opcion => opcion.trim()).length < 2
        || !reto.opciones[reto.correcta]?.trim())) avisos.push('añade dos opciones y selecciona la correcta');
    if (reto.tipo === 'ordenar' && (reto.orden.length < 2 || reto.orden.some(pieza => !pieza.trim())
        || new Set(reto.orden.map(normalizar)).size !== reto.orden.length)) {
      avisos.push('añade al menos dos piezas distintas en su orden correcto');
    }
    if (reto.tipo === 'combinacion' && !normalizar(reto.combinacion)) avisos.push('escribe la combinación válida');
    if (dia === 24 && !reto.premio.trim()) avisos.push('añade el premio o su escondite');
    if (Boolean(reto.evidenciaTitulo.trim()) !== Boolean(reto.evidenciaTexto.trim())) {
      avisos.push('completa el título y el contenido de la evidencia');
    }
    for (const campo of ['imagen', 'audio']) {
      if (reto[campo].trim() && !rutaMultimedia(reto[campo])) avisos.push(`revisa la ruta de ${campo}`);
    }
    if (reto.imagen.trim() && !reto.alt.trim()) avisos.push('describe la imagen para quien no pueda verla');
    for (const dibujo of [reto.recursoTipo, reto.evidenciaDibujo]) {
      if (dibujo && !Object.hasOwn(window.EscapeRoom.recursos?.tipos ?? {}, dibujo)) {
        avisos.push('selecciona un tipo de dibujo válido');
      }
    }
    const disponibles = new Set(evidencias(datos).map(item => item.id));
    for (const id of reto.dependencias) {
      const origen = /^(?:evidencia-)([1-9]|1\d|2[0-4])$/.exec(id)?.[1];
      if (!origen) avisos.push('elimina la referencia a una evidencia desconocida');
      else if (+origen >= dia) avisos.push(`la evidencia del día ${origen} debe ganarse antes del día ${dia}`);
      else if (!disponibles.has(id)) avisos.push(`falta la evidencia del día ${origen}`);
    }
    return avisos;
  }

  function progreso(datos) {
    const abiertos = Array.isArray(datos?.abiertos) ? datos.abiertos : [];
    const resueltos = Array.isArray(datos?.resueltos) ? datos.resueltos : [];
    const cadena = dias.filter(dia => dias.slice(0, dia).every(anterior => resueltos.includes(anterior)));
    return {
      abiertos: [...new Set([...abiertos.filter(dia => dias.includes(dia)), ...cadena])],
      resueltos: cadena,
      pistas: Object.fromEntries(dias.flatMap(dia => {
        const cantidad = datos?.pistas?.[dia];
        return Number.isInteger(cantidad) && cantidad > 0 ? [[dia, cantidad]] : [];
      })),
      repeticiones: Object.fromEntries(cadena.filter(dia=>datos?.repeticiones?.[dia]===true).map(dia=>[dia,true])),
      introduccionVista: datos?.introduccionVista === true,
      historiaVista: datos?.historiaVista === true,
      desenlace: {
        etapa: Math.max(0, Math.min(6, Number.isInteger(datos?.desenlace?.etapa) ? datos.desenlace.etapa : 0)),
        confirmado: datos?.desenlace?.confirmado === true,
        nombre: texto(datos?.desenlace?.nombre).slice(0,40)
      },
      interacciones: datos?.interacciones && typeof datos.interacciones === 'object'
        && !Array.isArray(datos.interacciones) ? datos.interacciones : {}
    };
  }

  function estado(dia, fecha, avance) {
    if (fecha < fechaPuerta(dia)) return 'futura';
    if (avance.resueltos.includes(dia)) return 'resuelta';
    if (dia > 1 && !avance.resueltos.includes(dia - 1)) return 'sin-llave';
    return 'disponible';
  }

  // Se deriva del progreso existente: no duplica ni modifica las evidencias de los acertijos.
  function descubrimientos(datos, avance) {
    return dias.filter(dia => avance.resueltos.includes(dia)).flatMap(dia => {
      const reto = datos.capitulos[dia - 1];
      return reto.transicion || reto.descubrimientoTexto ? [{dia,
        titulo: reto.descubrimientoTitulo || reto.titulo,
        transicion: reto.transicion, texto: reto.descubrimientoTexto}] : [];
    });
  }

  function acertada(reto, respuesta) {
    if (window.EscapeRoom.especiales?.esEspecial(reto.tipo)) {
      return window.EscapeRoom.especiales.acertada(reto, respuesta);
    }
    if (reto.tipo === 'opciones') return Number.isInteger(respuesta) && respuesta === reto.correcta;
    if (reto.tipo === 'ordenar') {
      return Array.isArray(respuesta) && respuesta.length === reto.orden.length
        && reto.orden.every((pieza, i) => pieza === respuesta[i]);
    }
    const limpiar = valor => reto.normalizacion === 'frase'
      ? normalizar(valor).replace(/[\p{P}\p{S}]/gu, ' ').replace(/\s+/g, ' ').trim()
      : normalizar(valor);
    const valor = limpiar(texto(respuesta));
    const validas = reto.tipo === 'combinacion' ? [reto.combinacion] : reto.respuestas;
    return Boolean(valor) && validas.some(solucion => limpiar(solucion) === valor);
  }

  function local() {
    return location.protocol === 'file:'
      || ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
  }

  window.EscapeRoom = {
    dias, tipos, capitulo, calendario, idEvidencia, evidencias, rutaMultimedia, errores,
    progreso, estado, descubrimientos, acertada, fechaPuerta, local, hoy: () => relojMadrid.format(new Date())
  };
}();
